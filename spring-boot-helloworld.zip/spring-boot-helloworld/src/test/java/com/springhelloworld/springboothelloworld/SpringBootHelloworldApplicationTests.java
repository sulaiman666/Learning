package com.springhelloworld.springboothelloworld;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootHelloworldApplicationTests {

	@Test
	void contextLoads() {
	}

}
